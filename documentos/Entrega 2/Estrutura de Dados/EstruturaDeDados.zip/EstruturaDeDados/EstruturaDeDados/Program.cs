﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EstruturaDeDados
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // ======= ATIVIDADES =======
            List<Atividade> listaAtividades = new List<Atividade>
            {
                new Atividade { Titulo = "Campanha do Agasalho", Descricao = "Arrecadação de roupas de inverno.", Data = new DateTime(2025, 5, 10) },
                new Atividade { Titulo = "Natal Solidário", Descricao = "Distribuição de brinquedos para crianças.", Data = new DateTime(2024, 12, 22) },
                new Atividade { Titulo = "Feira de Adoção de Animais", Descricao = "Parceria com abrigos locais.", Data = new DateTime(2025, 8, 15) }
            };

            Console.WriteLine("======= NOSSAS ATIVIDADES =======\n");
            listaAtividades.OrderByDescending(a => a.Data).ToList().ForEach(Console.WriteLine);

            // ======= TRANSPARÊNCIA =======
            List<ItemTransparencia> listaTransparencia = new List<ItemTransparencia>
            {
                new ItemTransparencia { Descricao = "Doação da Empresa X", Valor = 5000.00m, DataLancamento = new DateTime(2025, 7, 20) },
                new ItemTransparencia { Descricao = "Pagamento de Aluguel", Valor = -1500.00m, DataLancamento = new DateTime(2025, 8, 5) },
                new ItemTransparencia { Descricao = "Venda de produtos na feira", Valor = 850.50m, DataLancamento = new DateTime(2025, 7, 25) },
                new ItemTransparencia { Descricao = "Pagamento de Contas (Luz, Água)", Valor = -450.75m, DataLancamento = new DateTime(2025, 8, 10) }
            };

            Console.WriteLine("\n======= TRANSPARÊNCIA =======\n");
            listaTransparencia.OrderByDescending(t => t.DataLancamento).ToList().ForEach(Console.WriteLine);

            // ======= DOCUMENTOS =======
            List<Documentos> listaDocumentos = new List<Documentos>
            {
                new Documentos { Nome = "Relatório Anual", Tipo = "PDF", DataEnvio = new DateTime(2025, 6, 30) },
                new Documentos { Nome = "Ata de Reunião", Tipo = "DOCX", DataEnvio = new DateTime(2025, 5, 15) }
            };

            Console.WriteLine("\n======= DOCUMENTOS =======\n");
            listaDocumentos.OrderByDescending(d => d.DataEnvio).ToList().ForEach(Console.WriteLine);

            Console.WriteLine("\nExecução finalizada. Pressione qualquer tecla para sair...");
            Console.ReadKey();
        }
    }
}


﻿using System;

namespace EstruturaDeDados
{
    public class Atividade
    {
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public DateTime Data { get; set; }

        public override string ToString()
        {
            return $"Data: {Data:dd/MM/yyyy} - Título: {Titulo}\n  Descrição: {Descricao}\n";
        }
    }
}

﻿using System;

namespace EstruturaDeDados
{
    public class ItemTransparencia
    {
        public string Descricao { get; set; }
        public decimal Valor { get; set; }
        public DateTime DataLancamento { get; set; }
        public string Tipo => Valor >= 0 ? "Receita" : "Despesa";

        public override string ToString()
        {
            return $"Data: {DataLancamento:dd/MM/yyyy} - Tipo: {Tipo} - Valor: R$ {Valor:F2}\n  Descrição: {Descricao}\n";
        }
    }
}


﻿using System;

namespace EstruturaDeDados
{
    public class Documentos
    {
        public string Nome { get; set; }
        public string Tipo { get; set; }
        public DateTime DataEnvio { get; set; }

        public override string ToString()
        {
            return $"Documento: {Nome} ({Tipo}) - Enviado em: {DataEnvio:dd/MM/yyyy}\n";
        }
    }
}
